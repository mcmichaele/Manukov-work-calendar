Drop monthly schedule screenshots into this folder to trigger an automatic calendar update.

Supported formats: .png, .jpg, .jpeg

The GitHub Action will read the image, find Manukov's shifts, and update manukov.ics automatically.
